
import logging
import re
from collections import Counter
from typing import Any, Dict, List

from engine.graph.state import (
    InvestigativeState,
    AgentOutputItem,
    FindingItem,
    CitationItem,
)
from engine.tools.database_tools import query_cases, query_incidents
from engine.utils.logger import AgentExecutionTimer
from engine.utils.security_audit import SecurityAuditService

logger = logging.getLogger("CrimeMind.CaseAgent")


class CaseAgent:
    """
    Retrieves real case records and incident data.

    Ledger queries:
    - Query PostgreSQL separately for each requested status.
    - Return actual case IDs and case numbers.
    - Report zero when a status has no matching records.
    - Never substitute mock data or invent case records.
    """

    NAME = "Case Agent"
    LEDGER_STATUSES = ("open", "closed", "reopened")
    MAX_CASES = 5000

    @classmethod
    def _is_ledger_query(cls, query: str) -> bool:
        """Identify requests for a case-status ledger."""
        q = query.lower()

        mentions_case = any(
            term in q
            for term in ("case", "cases", "ledger", "status")
        )

        mentions_status = any(
            re.search(rf"\b{re.escape(status)}\b", q)
            for status in cls.LEDGER_STATUSES
        )

        return mentions_case and (
            mentions_status or "ledger" in q
        )

    @classmethod
    def _requested_statuses(cls, query: str) -> List[str]:
        """Extract explicitly requested ledger statuses."""
        q = query.lower()

        requested = [
            status
            for status in cls.LEDGER_STATUSES
            if re.search(rf"\b{re.escape(status)}\b", q)
        ]

        # A general case-ledger request includes all three categories.
        return requested or list(cls.LEDGER_STATUSES)

    @classmethod
    async def execute(
        cls,
        state: InvestigativeState,
    ) -> InvestigativeState:
        with AgentExecutionTimer(
            cls.NAME,
            f"Retrieving cases for query: {state.query[:60]}",
        ) as timer:
            try:
                is_ledger = cls._is_ledger_query(state.query)

                if is_ledger and not state.case_id:
                    cases, status_counts = cls._retrieve_ledger(
                        state.query
                    )
                    incidents = []
                else:
                    cases = query_cases(
                        case_id=state.case_id,
                        limit=cls.MAX_CASES if is_ledger else 50,
                    )
                    incidents = query_incidents(
                        case_id=state.case_id,
                        limit=50,
                    )
                    status_counts = dict(
                        Counter(
                            str(c.get("status", "unknown")).lower()
                            for c in cases
                        )
                    )

                state.cases.extend(cases)

                findings_list: List[str] = []

                if is_ledger and not state.case_id:
                    findings_list.extend(
                        cls._format_ledger_findings(
                            cases=cases,
                            status_counts=status_counts,
                            requested_statuses=cls._requested_statuses(
                                state.query
                            ),
                        )
                    )
                else:
                    for case in cases:
                        case_number = case.get(
                            "case_number", "Unknown"
                        )
                        case_status = case.get(
                            "status", "unknown"
                        )
                        title = case.get("title") or "Untitled case"

                        findings_list.append(
                            f"Case ID: {case.get('case_id', 'N/A')} | "
                            f"Case number: {case_number} | "
                            f"Status: {case_status} | "
                            f"Title: {title} | "
                            f"Priority: {case.get('priority', 'unknown')} | "
                            f"Crime type: {case.get('crime_type', 'unknown')}"
                        )

                        state.add_finding(
                            FindingItem(
                                category="OBSERVED FACT",
                                title=f"Case record: {case_number}",
                                finding=(
                                    f"Database record lists status "
                                    f"'{case_status}' for case "
                                    f"'{case_number}'."
                                ),
                                supporting_evidence_ids=[
                                    case["case_id"]
                                ] if case.get("case_id") else [],
                                confidence=1.0,
                                status="RECORDED OFFICIAL RECORD",
                            )
                        )

                        state.add_citation(
                            CitationItem(
                                citation_id=f"cit-case-{case_number}",
                                source_type="EVIDENCE",
                                reference_id=str(
                                    case.get("case_id", case_number)
                                ),
                                summary=(
                                    f"Case database record: {case_number}; "
                                    f"status: {case_status}."
                                ),
                            )
                        )

                output_data: Dict[str, Any] = {
                    "cases_retrieved": len(cases),
                    "incidents_retrieved": len(incidents),
                    "status_counts": status_counts,
                    "source": "PostgreSQL",
                    "synthetic_fallback_used": False,
                }

                if is_ledger and not state.case_id:
                    output_data["requested_statuses"] = (
                        self_statuses := cls._requested_statuses(
                            state.query
                        )
                    )
                    output_data["cases"] = [
                        {
                            "case_id": str(c.get("case_id", "")),
                            "case_number": c.get("case_number"),
                            "status": c.get("status"),
                        }
                        for c in cases
                    ]

                output = AgentOutputItem(
                    agent_name=cls.NAME,
                    task=(
                        "Retrieve case-status ledger from PostgreSQL"
                        if is_ledger
                        else "Retrieve case files and incident records"
                    ),
                    status="completed",
                    execution_time_ms=timer.duration_ms,
                    confidence=1.0,
                    findings=findings_list,
                    data=output_data,
                )
                state.add_agent_output(output)

                SecurityAuditService.record_agent_run(
                    case_id=state.case_id,
                    agent_name=cls.NAME,
                    task=(
                        "Case Status Ledger"
                        if is_ledger
                        else "Case File Retrieval"
                    ),
                    status="completed",
                    duration_ms=timer.duration_ms,
                    confidence=1.0,
                    output_summary={
                        "cases_found": len(cases),
                        "status_counts": status_counts,
                        "source": "PostgreSQL",
                    },
                )

            except Exception as exc:
                logger.exception(
                    "Case Agent failed to retrieve database records"
                )
                state.add_error(cls.NAME, str(exc))
                state.add_agent_output(
                    AgentOutputItem(
                        agent_name=cls.NAME,
                        task="Retrieve real case database records",
                        status="failed",
                        execution_time_ms=timer.duration_ms,
                        confidence=0.0,
                        findings=[],
                        errors=(
                            "Database-backed case retrieval failed. "
                            "No synthetic replacement records were returned. "
                            f"Details: {exc}"
                        ),
                    )
                )

        return state

    @classmethod
    def _retrieve_ledger(
        cls,
        query: str,
    ) -> tuple[List[Dict[str, Any]], Dict[str, int]]:
        """Fetch the requested exact statuses from the database."""
        requested_statuses = cls._requested_statuses(query)
        all_cases: List[Dict[str, Any]] = []
        counts: Dict[str, int] = {}

        for status in requested_statuses:
            records = query_cases(
                status=status,
                limit=cls.MAX_CASES,
            )

            # Protect against a query returning an unexpected status.
            matching_records = [
                record
                for record in records
                if str(record.get("status", "")).lower() == status
            ]

            counts[status] = len(matching_records)
            all_cases.extend(matching_records)

        return all_cases, counts

    @classmethod
    def _format_ledger_findings(
        cls,
        cases: List[Dict[str, Any]],
        status_counts: Dict[str, int],
        requested_statuses: List[str],
    ) -> List[str]:
        """Format counts and every returned case record."""
        findings: List[str] = [
            "SOURCE: PostgreSQL case records. "
            "The following are database results, not AI inferences."
        ]

        for status in requested_statuses:
            findings.append(
                f"STATUS SUMMARY | {status}: "
                f"{status_counts.get(status, 0)} cases"
            )

        for case in cases:
            findings.append(
                f"Case ID: {case.get('case_id', 'N/A')} | "
                f"Case number: {case.get('case_number', 'N/A')} | "
                f"Status: {case.get('status', 'unknown')}"
            )

        return findings
